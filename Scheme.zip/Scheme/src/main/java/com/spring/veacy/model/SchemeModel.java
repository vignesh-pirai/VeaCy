package com.spring.veacy.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SchemeModel {

	private String schemeName;
	private String schemeDescription;
	private Long auditingId;
	private Boolean isActive = true;
}
