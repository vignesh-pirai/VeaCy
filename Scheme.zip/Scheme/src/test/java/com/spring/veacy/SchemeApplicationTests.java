package com.spring.veacy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchemeApplicationTests {

	@Test
	void contextLoads() {
	}

}
